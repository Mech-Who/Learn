from setuptools import setup

setup(name='Hello',
      version='1.0',
      description='A simple example',
      author='Magus Lie  Hetland',
      py_modules=['hello'])
