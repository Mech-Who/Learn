print('Hello World!')
